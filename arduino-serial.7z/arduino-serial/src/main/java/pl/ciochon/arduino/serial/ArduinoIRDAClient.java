package pl.ciochon.arduino.serial;


import pl.ciochon.arduino.serial.command.CommandExecutor;
import pl.ciochon.arduino.serial.connection.Connection;
import pl.ciochon.arduino.serial.connection.EventListener;
import pl.ciochon.arduino.serial.connection.event.EventDispatcher;
import pl.ciochon.arduino.serial.pilot.event.impl.PilotSystemEventDispatcher;
import pl.ciochon.arduino.serial.pilot.impl.PlayStationPilot;

public class ArduinoIRDAClient {

    private static final String PORT_NAME = "COM4";

    public static void main(String[] args) throws Exception {
        Connection connection = new Connection();
        connection.setPortName(PORT_NAME);
        connection.initialize();

        EventDispatcher sysEventDispatcher = prepareSysEventDispatcher();

        EventListener eventListener = new EventListener();
        eventListener.setInput(connection.getInput());
        eventListener.setEventDispatcher(sysEventDispatcher);

        connection.addEventListener(eventListener);



        Thread t = new Thread() {
            public void run() {
                try {
                    Thread.sleep(500000000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        t.start();

//        System.out.println("Started");
//        while(true){
//            int tmp = new InputStreamReader(System.in).read ();
//            connection.getOutput().write(tmp);
//        }
    }

    private static EventDispatcher prepareSysEventDispatcher() {
        PilotSystemEventDispatcher pilotSystemEventDispatcher = new PilotSystemEventDispatcher();
        pilotSystemEventDispatcher.setPilot(new PlayStationPilot());
        pilotSystemEventDispatcher.setCommandExecutor(new CommandExecutor());
        return pilotSystemEventDispatcher;
    }

}