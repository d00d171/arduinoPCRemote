package pl.ciochon.arduino.serial.command.impl;

import pl.ciochon.arduino.serial.command.BaseNIRCMDCommand;

/**
 * Created by Konrad Ciochoń on 2017-02-09.
 */
public class MuteCommand extends BaseNIRCMDCommand{
    public String getNirCmdArguments() {
        return "mutesysvolume 2";
    }
}
