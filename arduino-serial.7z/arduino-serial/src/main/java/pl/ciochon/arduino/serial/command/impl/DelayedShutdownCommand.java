package pl.ciochon.arduino.serial.command.impl;

import pl.ciochon.arduino.serial.command.BaseCmdStartCommand;
import pl.ciochon.arduino.serial.command.BaseNIRCMDCommand;

/**
 * Created by Konrad Ciochoń on 2017-02-10.
 */
public class DelayedShutdownCommand extends BaseCmdStartCommand{

    protected String getProgramToExecute() {
        return "shutdown -s -t 3600";
    }
}
