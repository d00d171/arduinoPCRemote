package pl.ciochon.arduino.serial.pilot.event.impl;

import pl.ciochon.arduino.serial.command.CommandExecutor;
import pl.ciochon.arduino.serial.connection.event.EventDispatcher;
import pl.ciochon.arduino.serial.pilot.Pilot;
import pl.ciochon.arduino.serial.pilot.PilotKey;

public abstract class PilotEventDispatcher implements EventDispatcher{

    private Pilot pilot;
    protected CommandExecutor commandExecutor;

    public void dispatch(String eventValue) {
        try {
            PilotKey key = pilot.mapKey(Long.valueOf(eventValue));
            if (key != null) {
                dispatch(key);
            }
        } catch (NumberFormatException e){

        }
    }

    protected abstract void dispatch(PilotKey pilotKey);

    public Pilot getPilot() {
        return pilot;
    }

    public void setPilot(Pilot pilot) {
        this.pilot = pilot;
    }

    public CommandExecutor getCommandExecutor() {
        return commandExecutor;
    }

    public void setCommandExecutor(CommandExecutor commandExecutor) {
        this.commandExecutor = commandExecutor;
    }

}
