package pl.ciochon.arduino.serial.command.impl;

import pl.ciochon.arduino.serial.command.BaseNIRCMDCommand;

/**
 * Created by Konrad Ciochoń on 2017-02-09.
 */
public class VolumeUpCommand extends BaseNIRCMDCommand {

    public String getNirCmdArguments() {
        return "changesysvolume 1000";
    }
}
