package pl.ciochon.arduino.serial.pilot;

import java.util.Map;

/**
 * Created by Konrad Ciochoń on 2017-02-09.
 */
public interface Pilot {

    public abstract PilotKey mapKey(long key);

}
