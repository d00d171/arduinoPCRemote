package pl.ciochon.arduino.serial.pilot;

import pl.ciochon.arduino.serial.exception.KeyUnrecognizedException;

/**
 * Created by Konrad Ciochoń on 2017-02-09.
 */
public enum PilotKey {
    VOLUME_UP, VOLUME_DOWN, MUTE, POWER, CANCEL;
}
