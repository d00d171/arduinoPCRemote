package pl.ciochon.arduino.serial.exception;

/**
 * Created by Konrad Ciochoń on 2017-02-09.
 */
public class ConfigurationException extends RuntimeException{

    public ConfigurationException(String message) {
        super(message);
    }

}
