package pl.ciochon.arduino.serial.connection.event;

/**
 * Created by Konrad Ciochoń on 2017-02-09.
 */
public interface EventDispatcher {

    public void dispatch(String eventValue);

}
