package pl.ciochon.arduino.serial.command;

import pl.ciochon.arduino.serial.command.BaseCmdStartCommand;

/**
 * Created by Konrad Ciochoń on 2017-02-09.
 */
public abstract class BaseNIRCMDCommand extends BaseCmdStartCommand {

    public abstract String getNirCmdArguments();

    protected String getProgramToExecute() {
      return "E:\\DOWNLOADS\\nircmd\\nircmd.exe " + getNirCmdArguments();
    }

}
