package pl.ciochon.arduino.serial.connection;

import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import pl.ciochon.arduino.serial.connection.event.EventDispatcher;

import java.io.BufferedReader;

public class EventListener implements SerialPortEventListener{

    private BufferedReader input;
    private EventDispatcher eventDispatcher;

    public void serialEvent(SerialPortEvent serialPortEvent) {
        if (serialPortEvent.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
            try {
                String inputValue = input.readLine();
                System.out.println(inputValue);
                eventDispatcher.dispatch(inputValue);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void setEventDispatcher(EventDispatcher eventDispatcher) {
        this.eventDispatcher = eventDispatcher;
    }

    public void setInput(BufferedReader input) {
        this.input = input;
    }
}
