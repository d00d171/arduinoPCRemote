package pl.ciochon.arduino.serial.pilot.event.impl;

import pl.ciochon.arduino.serial.command.impl.*;
import pl.ciochon.arduino.serial.pilot.PilotKey;

/**
 * Created by Konrad Ciochoń on 2017-02-09.
 */
public class PilotSystemEventDispatcher extends PilotEventDispatcher{

    protected void dispatch(PilotKey pilotKey) {
        switch (pilotKey) {
            case VOLUME_UP:
                commandExecutor.execute(new VolumeUpCommand());
                break;
            case VOLUME_DOWN:
                commandExecutor.execute(new VolumeDownCommand());
                break;
            case MUTE :
                commandExecutor.execute(new MuteCommand());
                break;
            case POWER :
                commandExecutor.execute(new DelayedShutdownCommand());
                break;
            case CANCEL:
                commandExecutor.execute(new DelayedShutdownCancelCommand());
        }
    }

}
